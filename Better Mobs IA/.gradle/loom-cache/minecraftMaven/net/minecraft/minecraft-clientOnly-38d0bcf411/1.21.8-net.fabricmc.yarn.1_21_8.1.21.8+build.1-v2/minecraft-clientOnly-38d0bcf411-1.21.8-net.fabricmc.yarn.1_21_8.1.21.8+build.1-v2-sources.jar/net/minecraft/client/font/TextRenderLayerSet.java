package net.minecraft.client.font;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public record TextRenderLayerSet(RenderLayer normal, RenderLayer seeThrough, RenderLayer polygonOffset, RenderPipeline guiPipeline) {
	public static TextRenderLayerSet ofIntensity(Identifier textureId) {
		return new TextRenderLayerSet(
			RenderLayer.getTextIntensity(textureId),
			RenderLayer.getTextIntensitySeeThrough(textureId),
			RenderLayer.getTextIntensityPolygonOffset(textureId),
			RenderPipelines.RENDERTYPE_TEXT_INTENSITY
		);
	}

	public static TextRenderLayerSet of(Identifier textureId) {
		return new TextRenderLayerSet(
			RenderLayer.getText(textureId), RenderLayer.getTextSeeThrough(textureId), RenderLayer.getTextPolygonOffset(textureId), RenderPipelines.RENDERTYPE_TEXT
		);
	}

	public RenderLayer getRenderLayer(TextRenderer.TextLayerType layerType) {
		return switch (layerType) {
			case NORMAL -> this.normal;
			case SEE_THROUGH -> this.seeThrough;
			case POLYGON_OFFSET -> this.polygonOffset;
		};
	}
}
