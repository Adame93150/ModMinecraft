package net.minecraft.client.font;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Language;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public interface MultilineText {
	MultilineText EMPTY = new MultilineText() {
		@Override
		public void drawCenterWithShadow(DrawContext context, int x, int y) {
		}

		@Override
		public void drawCenterWithShadow(DrawContext context, int x, int y, int lineHeight, int color) {
		}

		@Override
		public void drawWithShadow(DrawContext context, int x, int y, int lineHeight, int color) {
		}

		@Override
		public int draw(DrawContext context, int x, int y, int lineHeight, int color) {
			return y;
		}

		@Nullable
		@Override
		public Style getStyleAtCentered(int x, int y, int i, double mouseX, double mouseY) {
			return null;
		}

		@Nullable
		@Override
		public Style getStyleAtLeftAligned(int x, int y, int i, double mouseX, double mouseY) {
			return null;
		}

		@Override
		public int count() {
			return 0;
		}

		@Override
		public int getMaxWidth() {
			return 0;
		}
	};

	static MultilineText create(TextRenderer renderer, Text... texts) {
		return create(renderer, Integer.MAX_VALUE, Integer.MAX_VALUE, texts);
	}

	static MultilineText create(TextRenderer renderer, int maxWidth, Text... texts) {
		return create(renderer, maxWidth, Integer.MAX_VALUE, texts);
	}

	static MultilineText create(TextRenderer renderer, Text text, int maxWidth) {
		return create(renderer, maxWidth, Integer.MAX_VALUE, text);
	}

	static MultilineText create(TextRenderer renderer, int maxWidth, int maxLines, Text... texts) {
		return texts.length == 0 ? EMPTY : new MultilineText() {
			@Nullable
			private List<MultilineText.Line> lines;
			@Nullable
			private Language language;

			@Override
			public void drawCenterWithShadow(DrawContext context, int x, int y) {
				this.drawCenterWithShadow(context, x, y, 9, -1);
			}

			@Override
			public void drawCenterWithShadow(DrawContext context, int x, int y, int lineHeight, int color) {
				int i = y;

				for (MultilineText.Line line : this.getLines()) {
					context.drawTextWithShadow(renderer, line.text, x - line.width / 2, i, color);
					i += lineHeight;
				}
			}

			@Override
			public void drawWithShadow(DrawContext context, int x, int y, int lineHeight, int color) {
				int i = y;

				for (MultilineText.Line line : this.getLines()) {
					context.drawTextWithShadow(renderer, line.text, x, i, color);
					i += lineHeight;
				}
			}

			@Override
			public int draw(DrawContext context, int x, int y, int lineHeight, int color) {
				int i = y;

				for (MultilineText.Line line : this.getLines()) {
					context.drawText(renderer, line.text, x, i, color, false);
					i += lineHeight;
				}

				return i;
			}

			@Nullable
			@Override
			public Style getStyleAtCentered(int x, int y, int i, double mouseX, double mouseY) {
				List<MultilineText.Line> list = this.getLines();
				int j = MathHelper.floor((mouseY - y) / i);
				if (j >= 0 && j < list.size()) {
					MultilineText.Line line = (MultilineText.Line)list.get(j);
					int k = x - line.width / 2;
					if (mouseX < k) {
						return null;
					} else {
						int l = MathHelper.floor(mouseX - k);
						return renderer.getTextHandler().getStyleAt(line.text, l);
					}
				} else {
					return null;
				}
			}

			@Nullable
			@Override
			public Style getStyleAtLeftAligned(int x, int y, int i, double mouseX, double mouseY) {
				if (mouseX < x) {
					return null;
				} else {
					List<MultilineText.Line> list = this.getLines();
					int j = MathHelper.floor((mouseY - y) / i);
					if (j >= 0 && j < list.size()) {
						MultilineText.Line line = (MultilineText.Line)list.get(j);
						int k = MathHelper.floor(mouseX - x);
						return renderer.getTextHandler().getStyleAt(line.text, k);
					} else {
						return null;
					}
				}
			}

			private List<MultilineText.Line> getLines() {
				Language language = Language.getInstance();
				if (this.lines != null && language == this.language) {
					return this.lines;
				} else {
					this.language = language;
					List<StringVisitable> list = new ArrayList();

					for (Text text : texts) {
						list.addAll(renderer.wrapLinesWithoutLanguage(text, maxWidth));
					}

					this.lines = new ArrayList();
					int i = Math.min(list.size(), maxLines);
					List<StringVisitable> list2 = list.subList(0, i);

					for (int j = 0; j < list2.size(); j++) {
						StringVisitable stringVisitable = (StringVisitable)list2.get(j);
						OrderedText orderedText = Language.getInstance().reorder(stringVisitable);
						if (j == list2.size() - 1 && i == maxLines && i != list.size()) {
							StringVisitable stringVisitable2 = renderer.trimToWidth(stringVisitable, renderer.getWidth(stringVisitable) - renderer.getWidth(ScreenTexts.ELLIPSIS));
							StringVisitable stringVisitable3 = StringVisitable.concat(new StringVisitable[]{stringVisitable2, ScreenTexts.ELLIPSIS});
							this.lines.add(new MultilineText.Line(Language.getInstance().reorder(stringVisitable3), renderer.getWidth(stringVisitable3)));
						} else {
							this.lines.add(new MultilineText.Line(orderedText, renderer.getWidth(orderedText)));
						}
					}

					return this.lines;
				}
			}

			@Override
			public int count() {
				return this.getLines().size();
			}

			@Override
			public int getMaxWidth() {
				return Math.min(maxWidth, this.getLines().stream().mapToInt(MultilineText.Line::width).max().orElse(0));
			}
		};
	}

	void drawCenterWithShadow(DrawContext context, int x, int y);

	void drawCenterWithShadow(DrawContext context, int x, int y, int lineHeight, int color);

	void drawWithShadow(DrawContext context, int x, int y, int lineHeight, int color);

	int draw(DrawContext context, int x, int y, int lineHeight, int color);

	@Nullable
	Style getStyleAtCentered(int x, int y, int i, double mouseX, double mouseY);

	@Nullable
	Style getStyleAtLeftAligned(int x, int y, int i, double mouseX, double mouseY);

	int count();

	int getMaxWidth();

	@Environment(EnvType.CLIENT)
	public record Line(OrderedText text, int width) {
	}
}
