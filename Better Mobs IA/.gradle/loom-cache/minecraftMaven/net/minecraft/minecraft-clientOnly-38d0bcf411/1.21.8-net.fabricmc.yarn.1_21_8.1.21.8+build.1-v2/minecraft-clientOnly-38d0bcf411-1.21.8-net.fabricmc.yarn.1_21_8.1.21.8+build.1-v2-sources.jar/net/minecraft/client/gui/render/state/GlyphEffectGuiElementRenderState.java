package net.minecraft.client.gui.render.state;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.font.BakedGlyph;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public record GlyphEffectGuiElementRenderState(Matrix3x2f pose, BakedGlyph whiteGlyph, BakedGlyph.Rectangle effect, @Nullable ScreenRect scissorArea)
	implements SimpleGuiElementRenderState {
	@Override
	public void setupVertices(VertexConsumer vertices, float depth) {
		Matrix4f matrix4f = new Matrix4f().mul(this.pose).translate(0.0F, 0.0F, depth);
		this.whiteGlyph.drawRectangle(this.effect, matrix4f, vertices, 15728880, true);
	}

	@Override
	public RenderPipeline pipeline() {
		return this.whiteGlyph.getPipeline();
	}

	@Override
	public TextureSetup textureSetup() {
		return TextureSetup.of((GpuTextureView)Objects.requireNonNull(this.whiteGlyph.getTexture()));
	}

	@Nullable
	@Override
	public ScreenRect bounds() {
		return null;
	}
}
