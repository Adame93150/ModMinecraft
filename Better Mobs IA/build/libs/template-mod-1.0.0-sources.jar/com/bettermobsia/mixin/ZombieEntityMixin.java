package com.bettermobsia.mixin;

import com.bettermobsia.goal.AlertNearbyZombiesGoal;
import com.bettermobsia.goal.CustomBreakDoorGoal;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1400;
import net.minecraft.class_1428;
import net.minecraft.class_1642;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1642.class)
public abstract class ZombieEntityMixin extends class_1308 {

    protected ZombieEntityMixin(class_1299<? extends class_1308> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "initGoals", at = @At("TAIL"))
    private void injectCustomGoals(CallbackInfo ci) {
        // Attaque les poulets
        this.field_6185.method_6277(3, new class_1400<>(
            (class_1308)(Object)this,
            class_1428.class,
            true
        ));

        // Casse les portes en toute difficulté
        this.field_6201.method_6277(4, new CustomBreakDoorGoal((class_1642)(Object)this));
        
        this.field_6201.method_6277(5, new AlertNearbyZombiesGoal((class_1642)(Object)this));

    }
}
