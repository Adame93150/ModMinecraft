package com.bettermobsia.goal;

import java.util.function.Predicate;
import net.minecraft.class_1339;
import net.minecraft.class_1642;

public class CustomBreakDoorGoal extends class_1339 {

    public CustomBreakDoorGoal(class_1642 zombie) {
        // On passe un prédicat qui retourne toujours true (peu importe la difficulté)
        super(zombie, difficulty -> true);
    }
}
