package com.bettermobsia.goal;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1642;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;

public class AlertNearbyZombiesGoal extends class_1352 {

    private final class_1642 zombie;

    public AlertNearbyZombiesGoal(class_1642 zombie) {
        this.zombie = zombie;
        this.method_6265(EnumSet.of(class_4134.field_18408));
    }

    @Override
    public boolean method_6264() {
        // Démarre uniquement si le zombie a une cible
        return this.zombie.method_5968() != null;
    }

    @Override
    public void method_6269() {
        class_1309 target = zombie.method_5968();

        // Rayon dans lequel les autres zombies seront alertés
        double radius = 50.0;
        class_238 box = zombie.method_5829().method_1014(radius);

        List<class_1642> nearbyZombies = zombie.method_37908().method_8390(
            class_1642.class,
            box,
            otherZombie -> otherZombie != zombie && otherZombie.method_5968() == null
        );

        for (class_1642 otherZombie : nearbyZombies) {
            otherZombie.method_5980(target);
        }

        // Générer des particules visibles (côté client)
        if (!zombie.method_37908().field_9236) {
            ((class_3218) zombie.method_37908()).method_65096(
                class_2398.field_11231,
                zombie.method_23317(), zombie.method_23318() + 1.5, zombie.method_23321(),
                5,       // nombre de particules
                0.3, 0.5, 0.3, // éparpillement (X, Y, Z)
                0.0      // vitesse
            );
        }
    }
}
